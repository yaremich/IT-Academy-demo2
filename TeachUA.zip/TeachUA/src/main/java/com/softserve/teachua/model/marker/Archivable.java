package com.softserve.teachua.model.marker;
/**
 * Mark interface for use ArchiveService class that adds a remote entity to the archive.
 *
 */
public interface Archivable {
}
